In order to make CAPTCHA work properly you need to download font and place it inside captcha directory. 
After that you need to change code inside simple-php-captcha.php file t desired font name.


Recommended font for CAPTCHA is:
Times New Yorker - http://www.dafont.com/times-new-yorker.font

This font is a free fo use.